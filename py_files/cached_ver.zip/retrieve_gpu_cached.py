from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
import numpy as np
import torch
from langchain_community.embeddings import HuggingFaceEmbeddings
import time


# =========================
# Numerics / helpers
# =========================
def _torch_l2norm_rows(X: torch.Tensor, eps: float = 1e-12) -> torch.Tensor:
    return X / (X.norm(dim=1, keepdim=True) + eps)

def _sigmoid(x: torch.Tensor) -> torch.Tensor:
    return 1.0 / (1.0 + torch.exp(-x))

def _distinct_greedy_numpy(S_attn: np.ndarray, distinct_tau: float) -> float:
    # EXACT same greedy as your original:
    # pick max, if < tau stop, remove row/col, sum/sqrt(taken)
    if S_attn.size == 0:
        return 0.0
    S_work = S_attn.copy()
    nq, nc = S_work.shape
    distinct_bonus = 0.0
    taken = 0
    for _ in range(min(nq, nc)):
        flat_idx = int(np.argmax(S_work))
        r, c = divmod(flat_idx, nc)
        val = float(S_work[r, c])
        if val < distinct_tau:
            break
        distinct_bonus += val
        S_work[r, :] = -np.inf
        S_work[:, c] = -np.inf
        taken += 1
    if taken > 0:
        distinct_bonus /= np.sqrt(taken)
    return float(distinct_bonus)


def _stack_float32(x_list: Any, name: str) -> np.ndarray:
    """Robustly stack list-of-vectors to (N,d) float32."""
    if x_list is None:
        raise KeyError(f"{name} missing")
    arrs = [np.asarray(v, dtype=np.float32).reshape(-1) for v in x_list]
    if not arrs:
        return np.zeros((0, 0), dtype=np.float32)
    d = arrs[0].shape[0]
    arrs = [a if a.shape[0] == d else np.zeros((d,), dtype=np.float32) for a in arrs]
    return np.stack(arrs, axis=0).astype(np.float32)


def _build_ent_rel_ids_padded_from_runs(
    edge_runs: List[List[int]],
    edge_matrix_np: np.ndarray,  # (n_edges, 3) [h,r,t]
) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """
    Replicates your decode_question(fmt="embeddings") + _extract_entities_relations_from_run behavior:
      entities are [h1, t1, h2, t2, ...], relations are [r1, r2, ...]
    Returns padded ids and masks:
      ent_ids: (N, max_ne) padded with -1
      rel_ids: (N, max_nr) padded with -1
      ent_mask, rel_mask: bool
    """
    N = len(edge_runs)
    max_L = max((len(r) for r in edge_runs), default=0)
    max_ne = 2 * max_L
    max_nr = max_L

    ent_ids = np.full((N, max_ne), -1, dtype=np.int64)
    rel_ids = np.full((N, max_nr), -1, dtype=np.int64)
    ent_mask = np.zeros((N, max_ne), dtype=np.bool_)
    rel_mask = np.zeros((N, max_nr), dtype=np.bool_)

    for i, run in enumerate(edge_runs):
        L = len(run)
        if L == 0:
            continue
        triples = edge_matrix_np[np.asarray(run, dtype=np.int64)]  # (L,3)
        h = triples[:, 0].astype(np.int64)
        r = triples[:, 1].astype(np.int64)
        t = triples[:, 2].astype(np.int64)

        ent = np.empty((2 * L,), dtype=np.int64)
        ent[0::2] = h
        ent[1::2] = t

        ent_ids[i, :2 * L] = ent
        rel_ids[i, :L] = r
        ent_mask[i, :2 * L] = True
        rel_mask[i, :L] = True

    return ent_ids, rel_ids, ent_mask, rel_mask



def _print_timings(timings: Dict[str, float]) -> None:
    total = timings.get("total", 1e-9)
    print("\n[TorchDBCache.build] Timing breakdown:")
    print(f"  {'Stage':<35} {'Time (s)':>10}  {'% of total':>10}")
    print(f"  {'-'*57}")
    for k, v in timings.items():
        if k == "total":
            continue
        pct = 100.0 * v / total
        print(f"  {k:<35} {v:>10.4f}s  {pct:>9.1f}%")
    print(f"  {'─'*57}")
    print(f"  {'TOTAL':<35} {total:>10.4f}s  {'100.0%':>10}\n")

@dataclass
class TorchDBCache:
    device: torch.device
    dtype: torch.dtype

    # normalized vocab embeddings
    e_emb: torch.Tensor        # (nE, d)
    r_emb: torch.Tensor        # (nR, d)
    edge_emb: torch.Tensor     # (n_edges, d)

    # flattened DB chunks (edge ids padded)
    db_edges: torch.Tensor      # (M, max_nc) long
    db_edge_mask: torch.Tensor  # (M, max_nc) bool
    db_nc: torch.Tensor         # (M,) long

    # chunk full embeddings (C_full) normalized
    db_full: torch.Tensor       # (M, d)

    # coarse-stage precomputed ids for maxpair similarity
    db_ent_ids: torch.Tensor    # (M, max_ne) long
    db_rel_ids: torch.Tensor    # (M, max_nr) long
    db_ent_mask: torch.Tensor   # (M, max_ne) bool
    db_rel_mask: torch.Tensor   # (M, max_nr) bool

    # mapping info
    db_qi: np.ndarray
    db_qj: np.ndarray
    db_src: str
    key_to_flat: Dict[Tuple[int, int, str], int]
    @staticmethod
    def build(
        codebook_main: Dict[str, Any],
        *,
        target: str = "questions",
        device: str = "cuda",
        dtype: torch.dtype = torch.float32,
        normalize: bool = True,
    ) -> "TorchDBCache":
        import time

        timings: Dict[str, float] = {}
        t_total = time.perf_counter()

        # Prefer deterministic-ish math
        if torch.cuda.is_available():
            torch.backends.cuda.matmul.allow_tf32 = False
            torch.backends.cudnn.allow_tf32 = False

        dev = torch.device(device if (device != "cuda" or torch.cuda.is_available()) else "cpu")

        # ---- base embeddings
        t0 = time.perf_counter()
        e_np = _stack_float32(codebook_main.get("e_embeddings"), "e_embeddings")
        r_np = _stack_float32(codebook_main.get("r_embeddings"), "r_embeddings")
        edge_np = _stack_float32(codebook_main.get("edge_matrix_embedding"), "edge_matrix_embedding")

        e_emb = torch.as_tensor(e_np, device=dev, dtype=torch.float32)
        r_emb = torch.as_tensor(r_np, device=dev, dtype=torch.float32)
        edge_emb = torch.as_tensor(edge_np, device=dev, dtype=torch.float32)
        timings["stack_base_embeddings"] = time.perf_counter() - t0

        t0 = time.perf_counter()
        if normalize:
            e_emb = _torch_l2norm_rows(e_emb)
            r_emb = _torch_l2norm_rows(r_emb)
            edge_emb = _torch_l2norm_rows(edge_emb)
        e_emb = e_emb.to(dtype)
        r_emb = r_emb.to(dtype)
        edge_emb = edge_emb.to(dtype)
        timings["normalize_base_embeddings"] = time.perf_counter() - t0

        # ---- DB selection
        t0 = time.perf_counter()
        if target == "questions":
            q_groups_hist = codebook_main.get("questions_lst", [])[:-1]
            use_answers_db = not any(len(g) > 0 for g in q_groups_hist)
            if use_answers_db:
                groups_for_db = codebook_main.get("answers_lst", [])
                groups_emb = codebook_main.get("answers_lst_embedding", [])
                db_src = "answers"
                print(f'db_src is {db_src}')
            else:
                groups_for_db = q_groups_hist
                groups_emb = codebook_main.get("questions_lst_embedding", [])[:-1]
                db_src = "questions"
                print(f'db_src is {db_src}')
        elif target == "facts":
            groups_for_db = codebook_main.get("facts_lst", [])
            groups_emb = codebook_main.get("facts_lst_embedding", [])
            db_src = "facts"
        else:
            raise ValueError("target must be 'questions' or 'facts'")
        timings["db_selection"] = time.perf_counter() - t0

        # ---- flatten DB
        t0 = time.perf_counter()
        db_runs: List[List[int]] = []
        db_full_list: List[np.ndarray] = []
        db_qi: List[int] = []
        db_qj: List[int] = []
        key_to_flat: Dict[Tuple[int, int, str], int] = {}

        for qi, group in enumerate(groups_for_db):
            for qj, run in enumerate(group):
                flat = len(db_runs)
                db_runs.append([int(x) for x in run])

                if not groups_emb:
                    raise KeyError(f"{db_src}_lst_embedding missing in codebook_main")
                v = np.asarray(groups_emb[qi][qj], dtype=np.float32).reshape(-1)
                db_full_list.append(v)

                db_qi.append(int(qi))
                db_qj.append(int(qj))
                key_to_flat[(int(qi), int(qj), db_src)] = flat

        M = len(db_runs)
        d = int(edge_emb.shape[1]) if edge_emb.ndim == 2 else 0
        timings["flatten_db"] = time.perf_counter() - t0

        if M == 0:
            # (empty path unchanged, skip timing detail)
            empty = torch.zeros((0, 1), device=dev, dtype=torch.long)
            emptyb = torch.zeros((0, 1), device=dev, dtype=torch.bool)
            emptyf = torch.zeros((0, d), device=dev, dtype=dtype)
            empty1 = torch.zeros((0,), device=dev, dtype=torch.long)
            timings["total"] = time.perf_counter() - t_total
            _print_timings(timings)
            return TorchDBCache(
                device=dev, dtype=dtype,
                e_emb=e_emb, r_emb=r_emb, edge_emb=edge_emb,
                db_edges=empty, db_edge_mask=emptyb, db_nc=empty1,
                db_full=emptyf,
                db_ent_ids=empty, db_rel_ids=empty,
                db_ent_mask=emptyb, db_rel_mask=emptyb,
                db_qi=np.zeros((0,), dtype=np.int32),
                db_qj=np.zeros((0,), dtype=np.int32),
                db_src=db_src,
                key_to_flat={},
            )

        # ---- padded edge ids
        # t0 = time.perf_counter()
        # max_nc = max(len(x) for x in db_runs)
        # db_edges = torch.full((M, max_nc), -1, device=dev, dtype=torch.long)
        # db_mask = torch.zeros((M, max_nc), device=dev, dtype=torch.bool)
        # db_nc = torch.zeros((M,), device=dev, dtype=torch.long)

        # for i, run in enumerate(db_runs):
        #     L = len(run)
        #     db_nc[i] = L
        #     if L == 0:
        #         continue
        #     t = torch.as_tensor(run, device=dev, dtype=torch.long)
        #     db_edges[i, :L] = t
        #     db_mask[i, :L] = True
        # timings["build_padded_edge_ids"] = time.perf_counter() - t0


        # ---- padded edge ids (vectorized)
        t0 = time.perf_counter()
        max_nc = max(len(x) for x in db_runs)
        db_nc_np = np.array([len(r) for r in db_runs], dtype=np.int64)

        # Build padded array entirely in numpy, then send to device in one shot
        db_edges_np = np.full((M, max_nc), -1, dtype=np.int64)
        for i, run in enumerate(db_runs):
            L = len(run)
            if L > 0:
                db_edges_np[i, :L] = run

        db_edges = torch.as_tensor(db_edges_np, device=dev, dtype=torch.long)
        db_nc    = torch.as_tensor(db_nc_np, device=dev, dtype=torch.long)

        # length-based mask: equivalent to original, immune to edge id value assumptions
        row_idx  = np.arange(max_nc)[None, :]                                      # (1, max_nc)
        db_mask  = torch.as_tensor(row_idx < db_nc_np[:, None], device=dev, dtype=torch.bool)  # (M, max_nc)
        timings["build_padded_edge_ids"] = time.perf_counter() - t0

        # ---- chunk full embeddings
        t0 = time.perf_counter()
        db_full_np = np.stack(
            [v if v.shape[0] == db_full_list[0].shape[0] else np.zeros_like(db_full_list[0]) for v in db_full_list],
            axis=0
        ).astype(np.float32)
        db_full = torch.as_tensor(db_full_np, device=dev, dtype=torch.float32)
        if normalize and db_full.numel() > 0:
            db_full = _torch_l2norm_rows(db_full)
        db_full = db_full.to(dtype)
        timings["build_chunk_full_embeddings"] = time.perf_counter() - t0

        # ---- coarse-stage ent/rel ids
        t0 = time.perf_counter()
        edge_matrix_np = np.asarray(codebook_main["edge_matrix"], dtype=np.int64)
        db_ent_ids_np, db_rel_ids_np, db_ent_mask_np, db_rel_mask_np = _build_ent_rel_ids_padded_from_runs(
            db_runs, edge_matrix_np
        )

        db_ent_ids = torch.as_tensor(db_ent_ids_np, device=dev, dtype=torch.long)
        db_rel_ids = torch.as_tensor(db_rel_ids_np, device=dev, dtype=torch.long)
        db_ent_mask = torch.as_tensor(db_ent_mask_np, device=dev, dtype=torch.bool)
        db_rel_mask = torch.as_tensor(db_rel_mask_np, device=dev, dtype=torch.bool)
        timings["build_ent_rel_ids"] = time.perf_counter() - t0

        timings["total"] = time.perf_counter() - t_total
        _print_timings(timings)

        return TorchDBCache(
            device=dev, dtype=dtype,
            e_emb=e_emb, r_emb=r_emb, edge_emb=edge_emb,
            db_edges=db_edges, db_edge_mask=db_mask, db_nc=db_nc,
            db_full=db_full,
            db_ent_ids=db_ent_ids, db_rel_ids=db_rel_ids,
            db_ent_mask=db_ent_mask, db_rel_mask=db_rel_mask,
            db_qi=np.asarray(db_qi, dtype=np.int32),
            db_qj=np.asarray(db_qj, dtype=np.int32),
            db_src=db_src,
            key_to_flat=key_to_flat,
        )



# =========================
# Coarse stage EXACT (maxpair cosine on entities + relations)
# =========================
@torch.inference_mode()
def get_topk_word_embedding_batched_cross_sim_torch_exact(
    questions: List[List[int]],
    codebook_main: Dict[str, Any],
    *,
    cache: TorchDBCache,
    top_k: int = 200,
    w_ent: float = 1.0,
    w_rel: float = 0.3,
    db_block: int = 1024,
) -> Dict[int, List[Dict[str, Any]]]:

    N = len(questions)
    results: Dict[int, List[Dict[str, Any]]] = {i: [] for i in range(N)}
    if N == 0:
        return results

    M = int(cache.db_edges.shape[0])
    if M == 0:
        return results

    edge_matrix_np = np.asarray(codebook_main["edge_matrix"], dtype=np.int64)

    # query ids padded (CPU -> torch once)
    q_ent_ids_np, q_rel_ids_np, q_ent_mask_np, q_rel_mask_np = _build_ent_rel_ids_padded_from_runs(
        questions, edge_matrix_np
    )
    dev = cache.device
    q_ent_ids = torch.as_tensor(q_ent_ids_np, device=dev, dtype=torch.long)
    q_rel_ids = torch.as_tensor(q_rel_ids_np, device=dev, dtype=torch.long)
    q_ent_mask = torch.as_tensor(q_ent_mask_np, device=dev, dtype=torch.bool)
    q_rel_mask = torch.as_tensor(q_rel_mask_np, device=dev, dtype=torch.bool)

    # gather query embeddings (already normalized in cache)
    q_ent = cache.e_emb[q_ent_ids.clamp_min(0)].float() * q_ent_mask.unsqueeze(-1)
    q_rel = cache.r_emb[q_rel_ids.clamp_min(0)].float() * q_rel_mask.unsqueeze(-1)

    K = min(int(top_k), M)
    best_sc = torch.full((N, K), -1e9, device=dev, dtype=torch.float32)
    best_ix = torch.full((N, K), -1, device=dev, dtype=torch.long)

    def maxpair_cos_block(qA, qMask, bA, bMask) -> torch.Tensor:
        # qA: (N,qa,d), bA: (B,ba,d) -> (N,B) max dot
        S = torch.einsum("nqd,bkd->nbqk", qA, bA)  # (N,B,qa,ba)
        valid = qMask[:, None, :, None] & bMask[None, :, None, :]
        S = S.masked_fill(~valid, float("-inf"))
        m = S.max(dim=-1).values.max(dim=-1).values  # (N,B)
        m = torch.where(torch.isfinite(m), m, torch.zeros_like(m))
        return m

    for s in range(0, M, db_block):
        e = min(s + db_block, M)

        b_ent_ids = cache.db_ent_ids[s:e]
        b_rel_ids = cache.db_rel_ids[s:e]
        b_ent_mask = cache.db_ent_mask[s:e]
        b_rel_mask = cache.db_rel_mask[s:e]

        b_ent = cache.e_emb[b_ent_ids.clamp_min(0)].float() * b_ent_mask.unsqueeze(-1)
        b_rel = cache.r_emb[b_rel_ids.clamp_min(0)].float() * b_rel_mask.unsqueeze(-1)

        ent_sc = maxpair_cos_block(q_ent, q_ent_mask, b_ent, b_ent_mask)
        rel_sc = maxpair_cos_block(q_rel, q_rel_mask, b_rel, b_rel_mask)

        block_sc = w_ent * ent_sc + w_rel * rel_sc  # (N,B)
        k_local = min(K, e - s)
        sc_local, ix_local = torch.topk(block_sc, k_local, dim=1)
        ix_local = ix_local + s

        sc_cat = torch.cat([best_sc, sc_local], dim=1)
        ix_cat = torch.cat([best_ix, ix_local], dim=1)
        best_sc, pos = torch.topk(sc_cat, K, dim=1)
        best_ix = torch.gather(ix_cat, 1, pos)

    # emit original schema
    for i in range(N):
        cols = best_ix[i].tolist()
        scs = best_sc[i].tolist()
        entries = []
        for col, sc in zip(cols, scs):
            if col < 0:
                continue
            entries.append({
                "score": float(sc),
                "questions_index": int(cache.db_qi[col]),
                "question_index": int(cache.db_qj[col]),
                "db_source": cache.db_src,
            })
        results[i] = entries

    return results


# =========================
# Rerank stage EXACT (unique chunks + voters + full bonus)
# =========================
@torch.inference_mode()
def rerank_with_sentence_embeddings_score_with_coverage_torch_exact(
    questions: List[List[int]],
    codebook_main: Dict[str, Any],
    coarse_topk: Dict[int, List[Dict[str, Any]]],
    *,
    cache: TorchDBCache,
    questions_full_emb: np.ndarray,  # (N,d) tagged-text embeddings for queries
    top_m: int = 20,
    use_attention: bool = False,

    # same params as your original
    top_t: int = 3,
    cov_tau: float = 0.45, cov_weight: float = 0.10,
    pair_tau: float = 0.55, pair_temp: float = 0.10, pair_weight: float = 0.20, pair_norm: str = "sqrt",
    distinct_weight: float = 0.10, distinct_tau: float = 0.50,
    whole_weight: float = 0.10,
    whole_gate_tau: float = 0.55,
    whole_gate_temp: float = 0.15,
    whole_len_norm: str = "sqrt_nc",
    cand_block: int = 256,
) -> Dict[str, List]:

    N = len(questions)
    if N == 0:
        return {"score": [], "questions_index": [], "question_index": [], "db_source": [], "index_combo": []}

    dev = cache.device

    # normalize query full embeddings like your _l2norm_rows
    q_full = torch.as_tensor(np.asarray(questions_full_emb, dtype=np.float32), device=dev, dtype=torch.float32)
    q_full = _torch_l2norm_rows(q_full)

    # build padded query edge ids
    max_nq = max((len(q) for q in questions), default=0)
    q_edges = torch.full((N, max_nq), -1, device=dev, dtype=torch.long)
    q_mask = torch.zeros((N, max_nq), device=dev, dtype=torch.bool)
    for i, run in enumerate(questions):
        L = len(run)
        if L == 0:
            continue
        t = torch.as_tensor([int(x) for x in run], device=dev, dtype=torch.long)
        q_edges[i, :L] = t
        q_mask[i, :L] = True

    # edge-level embeddings for queries (already normalized in cache)
    Qe = cache.edge_emb[q_edges.clamp_min(0)].to(torch.float32) * q_mask.unsqueeze(-1)  # (N,max_nq,d)

    # (EDIT-1) build candidates as paired (key, flat) so indices always align
    cand_pairs: List[Tuple[Tuple[int, int, str], int]] = []
    seen = set()
    for i in range(N):
        for it in coarse_topk.get(i, []):
            key = (int(it["questions_index"]), int(it["question_index"]), it.get("db_source", cache.db_src))
            if key in seen:
                continue
            flat = cache.key_to_flat.get(key)
            if flat is None:
                continue
            seen.add(key)
            cand_pairs.append((key, flat))

    if not cand_pairs:
        return {"score": [], "questions_index": [], "question_index": [], "db_source": [], "index_combo": []}

    cand_keys = [k for k, _ in cand_pairs]
    cand_flat = [f for _, f in cand_pairs]
    C = len(cand_flat)

    # voter mask (N,C): query i nominated candidate c?
    key_to_cidx = {cand_keys[j]: j for j in range(C)}
    voter = torch.zeros((N, C), device=dev, dtype=torch.bool)
    for i in range(N):
        for it in coarse_topk.get(i, []):
            key = (int(it["questions_index"]), int(it["question_index"]), it.get("db_source", cache.db_src))
            j = key_to_cidx.get(key, None)
            if j is not None:
                voter[i, j] = True

    # attention weights a over query edges (depends only on query)
    if use_attention:
        sims = (Qe * q_full[:, None, :]).sum(-1)  # (N,max_nq)
        sims = sims.masked_fill(~q_mask, float("-inf"))

        # (EDIT-2) float64 exp+normalize like your numpy
        maxv = sims.max(dim=1, keepdim=True).values
        maxv = torch.where(torch.isfinite(maxv), maxv, torch.zeros_like(maxv))
        s = sims - maxv
        w = torch.exp(s.double()) * q_mask.double()
        w = w / (w.sum(dim=1, keepdim=True) + 1e-12)
        a = w.float()
    else:
        a = q_mask.float()
        a = a / (a.sum(dim=1, keepdim=True) + 1e-12)

    # pair_norm helper
    nq_cnt = q_mask.sum(dim=1).to(torch.float32)  # (N,)
    def _pair_norm(nc_cnt: torch.Tensor) -> torch.Tensor:
        prod = (nq_cnt[:, None] * nc_cnt[None, :]).clamp_min(1.0)
        if pair_norm == "sqrt":
            return torch.sqrt(prod)
        elif pair_norm == "log":
            return torch.log1p(prod)
        else:
            return torch.ones_like(prod)

    cand_scores = torch.zeros((C,), device=dev, dtype=torch.float32)
    cand_flat_t = torch.as_tensor(cand_flat, device=dev, dtype=torch.long)

    for s0 in range(0, C, cand_block):
        s1 = min(s0 + cand_block, C)
        flats = cand_flat_t[s0:s1]          # (B,)
        B = int(flats.numel())

        # chunk edges padded
        Cedg = cache.db_edges[flats]        # (B,max_nc)
        Cmsk = cache.db_edge_mask[flats]    # (B,max_nc)
        nc_cnt = Cmsk.sum(dim=1).to(torch.float32)  # (B,)

        Ce = cache.edge_emb[Cedg.clamp_min(0)].to(torch.float32) * Cmsk.unsqueeze(-1)  # (B,max_nc,d)

        # S: (N,B,max_nq,max_nc)
        S = torch.einsum("nqd,bkd->nbqk", Qe, Ce)
        valid = q_mask[:, None, :, None] & Cmsk[None, :, None, :]
        S = S.masked_fill(~valid, float("-inf"))

        S_attn = S * a[:, None, :, None]


        flat = S_attn.reshape(N, B, -1)
        Kpairs = int(flat.size(-1))

        if Kpairs == 0:
            rel = torch.zeros((N, B), device=flat.device, dtype=torch.float32)
        else:
            k_take = min(max(1, int(top_t)), Kpairs)  # <-- same idea as min(top_t, nq*nc)
            topv = torch.topk(flat, k_take, dim=-1, sorted=False).values
            fin = torch.isfinite(topv)
            rel = (topv.masked_fill(~fin, 0.0).sum(-1) / fin.sum(-1).clamp_min(1)).to(torch.float32)


        # coverage
        best_per_q = S.max(dim=-1).values  # (N,B,max_nq)
        covered = (best_per_q >= cov_tau) & q_mask[:, None, :]
        coverage = (covered.float() * a[:, None, :]).sum(-1)  # (N,B)

        # many-to-many soft count
        soft_hits = _sigmoid((S_attn - pair_tau) / max(1e-6, pair_temp))
        soft_hits = soft_hits.masked_fill(~valid, 0.0)
        good_pairs_soft = soft_hits.sum(dim=(-1, -2))  # (N,B)

        norm = _pair_norm(nc_cnt)  # (N,B)
        good_pairs_bonus = torch.log1p(good_pairs_soft / (norm + 1e-12))  # (N,B)

        # distinct greedy: do exact numpy loop only where voter true
        distinct = torch.zeros((N, B), device=dev, dtype=torch.float32)
        if distinct_weight > 0.0:
            vm = voter[:, s0:s1]
            for i in range(N):
                if not bool(vm[i].any().item()):
                    continue
                nq_i = int(q_mask[i].sum().item())
                if nq_i == 0:
                    continue
                for bj in torch.where(vm[i])[0].tolist():
                    nc_j = int(Cmsk[bj].sum().item())
                    if nc_j == 0:
                        continue
                    mat = S_attn[i, bj, :nq_i, :nc_j].detach().cpu().numpy().astype(np.float32)
                    distinct[i, bj] = float(_distinct_greedy_numpy(mat, distinct_tau=distinct_tau))

        f = rel + cov_weight * coverage + pair_weight * good_pairs_bonus + distinct_weight * distinct  # (N,B)

        # sum over voters (same as summing score_from_S over S_list)
        vm = voter[:, s0:s1].to(torch.float32)
        base = (vm * f).sum(dim=0)  # (B,)

        # whole bonus (mean over voters)
        if whole_weight > 0.0:
            Cfull = cache.db_full[flats].to(torch.float32)  # (B,d) normalized
            sims_whole = (q_full[:, None, :] * Cfull[None, :, :]).sum(-1)  # (N,B)

            cnt = voter[:, s0:s1].sum(dim=0).to(torch.float32)  # (B,)
            mean_whole = (vm * sims_whole).sum(dim=0) / cnt.clamp_min(1.0)

            if whole_len_norm == "sqrt_nc":
                len_factor = torch.sqrt(nc_cnt.clamp_min(1.0)) + 1e-12
            elif whole_len_norm == "log_nc":
                len_factor = torch.log1p(nc_cnt.clamp_min(1.0)) + 1e-12
            else:
                len_factor = 1.0

            s_whole_adj = mean_whole / len_factor
            whole_gate = _sigmoid((mean_whole - whole_gate_tau) / max(1e-6, whole_gate_temp))
            base = base + whole_weight * (whole_gate * s_whole_adj)

        cand_scores[s0:s1] = base

    # global top-m over candidates
    m = min(int(top_m), int(C))
    top_sc, top_pos = torch.topk(cand_scores, m)

    out = {"score": [], "questions_index": [], "question_index": [], "db_source": [], "index_combo": []}
    top_pos = top_pos.tolist()
    top_sc = top_sc.tolist()

    for pos, sc in zip(top_pos, top_sc):
        qi, qj, src = cand_keys[pos]
        out["score"].append(float(sc))
        out["questions_index"].append(int(qi))
        out["question_index"].append(int(qj))
        out["db_source"].append(src)
        out["index_combo"].append([int(qi), int(qj)])

    return out


# =========================
# =========================
def coarse_filter_torch(
    questions: List[List[int]],
    codebook_main: Dict[str, Any],
    sentence_emb: HuggingFaceEmbeddings,
    top_k: int = 200,
    top_m: int = 20,
    target: str = "questions",
    w_ent: float = 1.0,
    w_rel: float = 0.3,
) -> Dict[str, List]:
    
    time_start_all = time.time()
    
    cache = TorchDBCache.build(codebook_main, target=target, device="cuda", dtype=torch.float32)

    time_end = time.time() - time_start_all

    print(f'cache:spending {time_end}s')

    time_start = time.time()

    coarse = get_topk_word_embedding_batched_cross_sim_torch_exact(
        questions,
        codebook_main,
        cache=cache,
        top_k=top_k,
        w_ent=w_ent,
        w_rel=w_rel,
    )

    time_end = time.time() - time_start

    print(f'questions:spending {time_end}s')


    time_start = time.time()
    questions_full_emb = compute_query_full_embeddings_tagged(questions, codebook_main, sentence_emb)
    time_end = time.time() - time_start
    print(f'questions_full_emb:spending {time_end}s')


    time_start = time.time()
    reranked = rerank_with_sentence_embeddings_score_with_coverage_torch_exact(
        questions,
        codebook_main,
        coarse,
        cache=cache,
        questions_full_emb=questions_full_emb,
        top_m=top_m,
    )
    
    time_end = time.time() - time_start
    print(f'questions_full_emb:spending {time_end}s')

    time_end_all = time.time() - time_start_all

    print(f'spending total {time_end_all}s')
    return reranked

def compute_query_full_embeddings_tagged(
    questions: List[List[int]],
    codebook_main: Dict[str, Any],
    sentence_emb,  # HuggingFaceEmbeddings-like with .embed_documents(List[str])
    sep: str = " <SEP> ",
) -> np.ndarray:
    E = codebook_main["e"]
    R = codebook_main["r"]
    edge_matrix = codebook_main["edge_matrix"]

    texts = []
    for run in questions:
        parts = []
        for eid in run:
            h, r, t = edge_matrix[int(eid)]
            parts.append(f"[H]{E[h]} [R]{R[r]} [T]{E[t]}")
        texts.append(sep.join(parts))

    vecs = sentence_emb.embed_documents(texts)
    V = np.asarray(vecs, dtype=np.float32)
    V = V / (np.linalg.norm(V, axis=1, keepdims=True) + 1e-12)
    return V

